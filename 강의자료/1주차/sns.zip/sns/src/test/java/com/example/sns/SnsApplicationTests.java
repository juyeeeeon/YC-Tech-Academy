package com.example.sns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnsApplicationTests {

	@Test
	void contextLoads() {
	}

}

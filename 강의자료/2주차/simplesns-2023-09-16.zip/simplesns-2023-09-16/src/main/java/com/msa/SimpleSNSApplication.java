package com.msa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleSNSApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleSNSApplication.class, args);
	}

}

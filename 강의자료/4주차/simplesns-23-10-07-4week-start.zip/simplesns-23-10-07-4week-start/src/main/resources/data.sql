INSERT INTO POST (title, content, created_at) VALUES ('dhrl****', '전체관람가는 아닌것 같아요', now());
INSERT INTO POST (title, content, created_at) VALUES ('yuns****', '디렉터스컷으로봐서 거의 3시간짜리인데 참 흡인력있다', now());
INSERT INTO POST (title, content, created_at) VALUES ('supe****', '태어나 처음으로 가슴아리는 영화였다.  20년이상 지났지만.. 생각하면  또 가슴이 아리는.. 황순원의 소나기에서 또 한번 느꼈던 그 느낌!', now());
INSERT INTO POST (title, content, created_at) VALUES ('clai****', '어린시절 고딩때 봤던 때랑 또 결혼하고 나서 봤을때의 느낌은 확실히 다르네요. 뭔가 알프레도를 더 이해하게되고.. 토토와 알프레도의 우정이 정말 아름다운것이었음을, 토토의 첫사랑이 참 풋풋했음을 느낍니다~~그리고 언제들어도 사랑스러운 최고의 영화음악!', now());
INSERT INTO POST (title, content, created_at) VALUES ('dlag****', '토토에게 넓은 세상을 보여주고픈 알프레도.. 그가 토토를 위해 정을 떼려고 했던 장면에 왠지 씁쓸했고, 친구, 스승을 떠나 아버지 같은 느낌을 받게 되었다.. 평생 못잊을 장면이자 추억이다.', now());
INSERT INTO POST (title, content, created_at) VALUES ('data****', '아름다운 영화 지금까지 봤던 영화 중 끝까지 감동적이었던 영화', now());
INSERT INTO POST (title, content, created_at) VALUES ('"hoji****', '인생 최고의 영화. 말이 필요없음. 감독판은 감동이 좀 덜함', now());
INSERT INTO POST (title, content, created_at) VALUES ('vers****', '여지껏 내인생에서 젤 감동인 영화~!   영화음악의 거장 ''엔리오모리꼬네''의 OST까지 완벽하다...', now());
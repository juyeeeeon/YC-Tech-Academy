package com.msa.auth;


public enum JwtCode {
    ACCESS,EXPIRED,DENIED
}
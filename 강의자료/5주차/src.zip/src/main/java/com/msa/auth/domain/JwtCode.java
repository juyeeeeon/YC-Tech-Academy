package com.msa.auth.domain;

public enum JwtCode {
    ACCESS,EXPIRED,DENIED
}

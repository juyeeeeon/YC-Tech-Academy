package com.msa.member.dto;

public record SignupDto(String userName, String email, String password) {
}

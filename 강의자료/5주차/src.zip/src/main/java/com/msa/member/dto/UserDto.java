package com.msa.member.dto;

public record UserDto(String username, String email) {
}

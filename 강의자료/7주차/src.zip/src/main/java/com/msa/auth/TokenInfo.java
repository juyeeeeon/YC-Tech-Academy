package com.msa.auth;

public record TokenInfo(String accessToken, String refreshToken) {
}

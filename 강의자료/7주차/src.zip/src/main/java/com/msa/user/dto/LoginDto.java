package com.msa.user.dto;

public record LoginDto(String email, String password) {

}

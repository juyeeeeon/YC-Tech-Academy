package com.msa.user.dto;

public record SignupDto (String userName, String email, String password) {

}

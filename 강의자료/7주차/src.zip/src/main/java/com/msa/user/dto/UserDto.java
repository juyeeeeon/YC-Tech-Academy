package com.msa.user.dto;

public record UserDto(String userName, String email) {
}
